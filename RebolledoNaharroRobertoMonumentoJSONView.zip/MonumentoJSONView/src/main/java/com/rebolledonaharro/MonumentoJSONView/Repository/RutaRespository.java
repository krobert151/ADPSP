package com.rebolledonaharro.MonumentoJSONView.Repository;

import com.rebolledonaharro.MonumentoJSONView.Modal.Ruta;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RutaRespository extends JpaRepository<Ruta,Long> {
}
