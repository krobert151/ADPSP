package com.rebolledonaharro.MonumentoJSONView;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MonumentoJsonViewApplication {

	public static void main(String[] args) {
		SpringApplication.run(MonumentoJsonViewApplication.class, args);
	}

}
