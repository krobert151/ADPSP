package com.rebolledonaharro.MonumentoJSONView.Repository;

import com.rebolledonaharro.MonumentoJSONView.Modal.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository extends JpaRepository<Categoria,Long> {
}
