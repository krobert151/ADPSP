package com.rebolledonaharro.MonumentoJSONView.Repository;

import com.rebolledonaharro.MonumentoJSONView.Modal.Monumento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MonumentoRepository extends JpaRepository<Monumento,Long> {
}
