package com.rebolledonaharro.MonumentoJSONView.Modal;

public enum Dificultad {

    BAJA,
    MEDIA,
    ALTA;


}
