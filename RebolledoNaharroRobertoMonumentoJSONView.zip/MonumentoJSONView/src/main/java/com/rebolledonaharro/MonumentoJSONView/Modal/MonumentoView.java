package com.rebolledonaharro.MonumentoJSONView.Modal;

public class MonumentoView {

    public static class MonumentList{}
    public static class MonumentoDetail extends MonumentList{}
    public static class MonumentoEnRuta extends MonumentList{}

}
