package com.rebolledonaharro.MonumentoJSONView;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonumentoJsonViewApplicationTests {

	@Test
	void contextLoads() {
	}

}
