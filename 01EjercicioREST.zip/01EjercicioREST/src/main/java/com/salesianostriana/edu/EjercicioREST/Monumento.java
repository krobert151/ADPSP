package com.salesianostriana.edu.EjercicioREST;

import lombok.*;

@Data
@Builder
@Getter
@Setter
@AllArgsConstructor
public class Monumento {

    private int id;

    private String codigoPais;

    private String nombrePais;

    private String nombreCiudad;

    private Long latitud;

    private Long longuitud;

    private String nombreMonumento;

    private String descripcion;

    private String urlFoto;



}
