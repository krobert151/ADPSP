package com.rebolledonaharro.EjemploDTO2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjemploDto2Application {

	public static void main(String[] args) {
		SpringApplication.run(EjemploDto2Application.class, args);
	}

}
