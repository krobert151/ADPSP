package com.rebolledonaharro.identificadoresdeentidades;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IdentificadoresdeentidadesApplication {

	public static void main(String[] args) {
		SpringApplication.run(IdentificadoresdeentidadesApplication.class, args);
	}

}
